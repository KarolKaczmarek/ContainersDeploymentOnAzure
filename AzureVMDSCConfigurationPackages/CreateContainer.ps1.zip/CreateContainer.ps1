﻿configuration ContainerSetup
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, Position=0, ValueFromPipeline=$true)]
        [string] 
        $ContainerName
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration -Name WindowsFeature
    Import-DscResource -ModuleName nContainer
    
    LocalConfigurationManager
    {
        RebootNodeIfNeeded = $true
    }

    WindowsFeature ContainersFeature
    {
        Name =   'Containers'
        Ensure = 'Present'
    }

    Script DownloadImage # TODO This could be placed into ContainerImage resource (to also support downloading new OS images)
    {
        GetScript = { return @{} }
        SetScript = {
                $imageCollection = Get-ContainerImage # TODO Can we get image by specific name here? (WindowsServerCore) Download only if it's not present

                $localWimPath = "C:\ContainerBaseImage.wim" 
                $wimPath = "https://aka.ms/ContainerOSImage" # TODO This could be specified as parameter (together with ImageName)
                wget -Uri $WimPath -OutFile $localWimPath -UseBasicParsing
                Install-ContainerOsImage -WimPath $WimPath -Force # TODO confirm it's asynchronous (if it isn't then we don't need while below) (although perhaps that's not true, cause comment says that sleeping is to workaround some TP3 issue)

                while ($imageCollection -eq $null)
                {
                    #
                    # Sleeping to ensure VMMS has restarted to workaround TP3 issue
                    #
                    Start-Sleep -Sec 2
                
                    $imageCollection = Get-ContainerImage
                }
            }
        TestScript = { return ((Get-ContainerImage) -ne $null) }
        DependsOn = "[WindowsFeature]ContainersFeature"
    }

    nContainer Container
    {
        Name      = $ContainerName
        ImageName = 'WindowsServerCore'
        Ensure    = 'Present'
        State     = 'Off'
        VirtualSwitchName = 'Virtual Switch'
        DependsOn = "[Script]DownloadImage"
    }
}